<?php

$con=new mysqli('localhost','root','','crudoperation2');

if(!$con){
    die(mysqli_error($con));
}

?>